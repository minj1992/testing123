"""
gcs_to_pubsub_all11.py  --  Job 1

Reads all 11 dummy .jsonl files from Cloud Storage and publishes each
line to the correct REAL Pub/Sub topic -- 9 files to common-loan-topic,
1 file (customer-supplementals) to common-customer-topic.

Local test:  python gcs_to_pubsub_all11.py --runner=DirectRunner
"""
import argparse, os
import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions

# filename stem -> which real topic it belongs to
FILE_TO_TOPIC = {
    "TOPIC_account_loanslinesleases_lcm": "common-loan-topic",
    "TOPIC_product_rates": "common-loan-topic",
    "TOPIC_customer_supplementals": "common-customer-topic",
    "TOPIC_account_loanslinesleases_lcm_postedtransactions": "common-loan-topic",
    "TOPIC_account_supplementals": "common-loan-topic",
    "TOPIC_account_loanslinesleases_chargeheaders": "common-loan-topic",
    "TOPIC_account_relationships_accounts_supplemental": "common-loan-topic",
    "TOPIC_account_loanslinesleases_balanceheaders": "common-loan-topic",
    "TOPIC_account_loanslinesleases_billingschedules": "common-loan-topic",
    "TOPIC_account_loanslinesleases_chargeheaders_amounts": "common-loan-topic",
    "TOPIC_account_loanslinesleases_balanceheaders_amounts": "common-loan-topic",
}

def run():
    parser = argparse.ArgumentParser()
    parser.add_argument("--gcs_prefix", default=None)
    parser.add_argument("--local_dir", default="dummy_data_all11")
    parser.add_argument("--project_for_topics", default=None)
    known_args, pipeline_args = parser.parse_known_args()
    options = PipelineOptions(pipeline_args)
    local_mode = known_args.gcs_prefix is None

    with beam.Pipeline(options=options) as p:
        for stem, topic_name in FILE_TO_TOPIC.items():
            path = (os.path.join(known_args.local_dir, f"{stem}.jsonl") if local_mode
                    else f"{known_args.gcs_prefix}/{stem}.jsonl")
            lines = p | f"Read {stem}" >> beam.io.ReadFromText(path)
            encoded = lines | f"Encode {stem}" >> beam.Map(lambda line: line.encode("utf-8"))
            if local_mode:
                encoded | f"Print {stem}" >> beam.Map(
                    lambda b, t=topic_name: print(f"[would publish to {t}] {b.decode('utf-8')}"))
            else:
                topic_path = f"projects/{known_args.project_for_topics}/topics/{topic_name}"
                encoded | f"Publish {stem}" >> beam.io.WriteToPubSub(topic=topic_path)

if __name__ == "__main__":
    run()
