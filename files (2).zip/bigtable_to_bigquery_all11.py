"""
bigtable_to_bigquery_all11.py  --  the final step: Bigtable -> BigQuery

Reads all 11 TOPIC_ tables from Bigtable and writes each into a matching
BigQuery table, for analytics/SQL querying. This is "Option B" from
earlier (a real batch copy) -- Option A (a BigQuery external table
querying Bigtable live) is a single `bq mk` command instead of a job,
also shown in the lab guide.

Real run:
    python bigtable_to_bigquery_all11.py \
      --runner=DataflowRunner --project=YOUR_PROJECT_ID --region=us-central1 \
      --temp_location=gs://YOUR_BUCKET/temp \
      --bigtable_instance=afs-poc-bigtable --bq_dataset=afs_poc_analytics
"""

import argparse
import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions, GoogleCloudOptions

TABLES = [
    "TOPIC_account_loanslinesleases_lcm",
    "TOPIC_product_rates",
    "TOPIC_customer_supplementals",
    "account_loanslinesleases_lcm_postedtransactions",
    "TOPIC_account_supplementals",
    "TOPIC_account_loanslinesleases_chargeheaders",
    "TOPIC_account_relationships_accounts_supplemental",
    "TOPIC_account_loanslinesleases_balanceheaders",
    "TOPIC_account_loanslinesleases_billingschedules",
    "account_loanslinesleases_chargeheaders_amounts",
    "account_loanslinesleases_balanceheaders_amounts",
]

def bigtable_row_to_dict(row):
    out = {"bigtable_row_key": row.row_key.decode("utf-8")}
    for col, cells in row.cells.get("data", {}).items():
        out[col.decode("utf-8")] = cells[0].value.decode("utf-8")
    return out

def run():
    parser = argparse.ArgumentParser()
    parser.add_argument("--bigtable_instance", required=True)
    parser.add_argument("--bq_dataset", required=True)
    known_args, pipeline_args = parser.parse_known_args()
    options = PipelineOptions(pipeline_args)
    project_id = options.view_as(GoogleCloudOptions).project

    with beam.Pipeline(options=options) as p:
        for table_name in TABLES:
            from apache_beam.io.gcp.bigtableio import ReadFromBigTable
            rows = (p | f"Read {table_name}" >> ReadFromBigTable(
                        project_id=project_id, instance_id=known_args.bigtable_instance, table_id=table_name)
                      | f"Flatten {table_name}" >> beam.Map(bigtable_row_to_dict))
            rows | f"Write {table_name}" >> beam.io.WriteToBigQuery(
                f"{project_id}:{known_args.bq_dataset}.{table_name}",
                write_disposition=beam.io.BigQueryDisposition.WRITE_TRUNCATE,
                create_disposition=beam.io.BigQueryDisposition.CREATE_IF_NEEDED)

if __name__ == "__main__":
    run()
