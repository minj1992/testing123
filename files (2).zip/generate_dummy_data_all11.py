"""
generate_dummy_data_all11.py

Generates 2 dummy records for each of the 11 topics, every record
tagged with topic_name, and either writes them locally or uploads
them straight to Cloud Storage as .jsonl files -- one per topic.

Local test:  python generate_dummy_data_all11.py
Upload:      python generate_dummy_data_all11.py --gcs_bucket=afs-poc-data
"""
import argparse, json, os

TOPIC_FILES = {
    "TOPIC_account_loanslinesleases_lcm": [{'topic_name': 'account-loanslinesleases-lcm', 'accountLoanslinesleasesLcmId': 'T23-0001', 'accountLoanslinesleaseId': 'ACC-0001', 'applicationNumber': 'APP01', 'applicationSystem': 'AFSVISION', 'bankNumber': '001', 'financialInstrumentNumber': '4521', 'obligationNumber': '88012', 'obligorNumber': '4521', 'externalSourceTicklerReference': None}, {'topic_name': 'account-loanslinesleases-lcm', 'accountLoanslinesleasesLcmId': 'T23-0002', 'accountLoanslinesleaseId': 'ACC-0002', 'applicationNumber': 'APP01', 'applicationSystem': 'AFSVISION', 'bankNumber': '001', 'financialInstrumentNumber': '9310', 'obligationNumber': '204', 'obligorNumber': '9310', 'externalSourceTicklerReference': 'TKL-77'}],
    "TOPIC_product_rates": [{'topic_name': 'product-rates', 'productRateId': 'T33-0001', 'applicationNumber': 'APP01', 'applicationSystem': 'AFSVISION', 'bankNumber': '001', 'effectiveDate': '2026-09-01', 'effectiveTime': '10:00:00', 'externalSourceCustomerNameReference': 'CUSTNAME01', 'rateNumber': '4.25', 'sequenceNumber': '1'}, {'topic_name': 'product-rates', 'productRateId': 'T33-0002', 'applicationNumber': 'APP01', 'applicationSystem': 'AFSVISION', 'bankNumber': '001', 'effectiveDate': '2026-09-01', 'effectiveTime': '10:00:00', 'externalSourceCustomerNameReference': 'CUSTNAME01', 'rateNumber': '4.25', 'sequenceNumber': '1'}],
    "TOPIC_customer_supplementals": [{'topic_name': 'customer-supplementals', 'customerSupplementalId': 'T19-0001', 'customerId': 'ACC-0001', 'applicationNumber': 'APP01', 'applicationSystem': 'AFSVISION', 'bankNumber': '001', 'obligorNumber': '4521'}, {'topic_name': 'customer-supplementals', 'customerSupplementalId': 'T19-0002', 'customerId': 'ACC-0002', 'applicationNumber': 'APP01', 'applicationSystem': 'AFSVISION', 'bankNumber': '001', 'obligorNumber': '9310'}],
    "account_loanslinesleases_lcm_postedtransactions": [{'topic_name': 'account-loanslinesleases-lcm-postedtransactions', 'accountLoanslinesleasesLcmPostedtransactionId': 'T13-0001', 'accountLoanslinesleaseId': 'ACC-0001', 'applicationNumber': 'APP01', 'applicationSystem': 'AFSVISION', 'bankNumber': '001', 'effectiveDate': '2026-09-01', 'financialInstrumentNumber': '4521', 'obligationNumber': '88012', 'obligorNumber': '4521', 'offSetSequenceNumber': '0', 'sequenceNumber': '1', 'transactionRecordedTimestamp': '2026-09-01T10:00:00'}, {'topic_name': 'account-loanslinesleases-lcm-postedtransactions', 'accountLoanslinesleasesLcmPostedtransactionId': 'T13-0002', 'accountLoanslinesleaseId': 'ACC-0002', 'applicationNumber': 'APP01', 'applicationSystem': 'AFSVISION', 'bankNumber': '001', 'effectiveDate': '2026-09-01', 'financialInstrumentNumber': '9310', 'obligationNumber': '204', 'obligorNumber': '9310', 'offSetSequenceNumber': '0', 'sequenceNumber': '1', 'transactionRecordedTimestamp': '2026-09-01T10:00:00'}],
    "TOPIC_account_supplementals": [{'topic_name': 'account-supplementals', 'accountSupplementalId': 'T26-0001', 'accountId': 'ACC-0001', 'applicationNumber': 'APP01', 'applicationSystem': 'AFSVISION', 'bankNumber': '001', 'financialInstrumentNumber': '4521', 'obligationNumber': '88012', 'obligorNumber': '4521'}, {'topic_name': 'account-supplementals', 'accountSupplementalId': 'T26-0002', 'accountId': 'ACC-0002', 'applicationNumber': 'APP01', 'applicationSystem': 'AFSVISION', 'bankNumber': '001', 'financialInstrumentNumber': '9310', 'obligationNumber': '204', 'obligorNumber': '9310'}],
    "TOPIC_account_loanslinesleases_chargeheaders": [{'topic_name': 'account-loanslinesleases-chargeheaders', 'accountLoanslinesleasesChargeheaderId': 'T8-0001', 'accountLoanslinesleaseId': 'ACC-0001', 'applicationNumber': 'APP01', 'applicationSystem': 'AFSVISION', 'bankNumber': '001', 'chargeCode': '10', 'financialInstrumentNumber': '4521', 'obligationNumber': '88012', 'obligorNumber': '4521'}, {'topic_name': 'account-loanslinesleases-chargeheaders', 'accountLoanslinesleasesChargeheaderId': 'T8-0002', 'accountLoanslinesleaseId': 'ACC-0002', 'applicationNumber': 'APP01', 'applicationSystem': 'AFSVISION', 'bankNumber': '001', 'chargeCode': '22', 'financialInstrumentNumber': '9310', 'obligationNumber': '204', 'obligorNumber': '9310'}],
    "TOPIC_account_relationships_accounts_supplemental": [{'topic_name': 'account-relationships-accounts-supplemental', 'accountRelationshipsAccountsSupplementalId': 'T41-0001', 'accountRelationshipsAccountId': 'ACC-0001', 'applicationSystem': 'AFSVISION', 'financialInstrumentNumber': '4521', 'obligationNumber': '88012'}, {'topic_name': 'account-relationships-accounts-supplemental', 'accountRelationshipsAccountsSupplementalId': 'T41-0002', 'accountRelationshipsAccountId': 'ACC-0002', 'applicationSystem': 'AFSVISION', 'financialInstrumentNumber': '9310', 'obligationNumber': '204'}],
    "TOPIC_account_loanslinesleases_balanceheaders": [{'topic_name': 'account-loanslinesleases-balanceheaders', 'accountLoanslinesleasesBalanceheaderId': 'T7-0001', 'accountLoanslinesleaseId': 'ACC-0001', 'applicationSystem': 'AFSVISION', 'associatedPrincipalBalanceCode': 'P', 'balanceCode': 'CUR', 'bankNumber': '001', 'financialInstrumentNumber': '4521', 'obligationNumber': '88012', 'obligorNumber': '4521', 'sequenceNumber': '1'}, {'topic_name': 'account-loanslinesleases-balanceheaders', 'accountLoanslinesleasesBalanceheaderId': 'T7-0002', 'accountLoanslinesleaseId': 'ACC-0002', 'applicationSystem': 'AFSVISION', 'associatedPrincipalBalanceCode': 'P', 'balanceCode': 'CUR', 'bankNumber': '001', 'financialInstrumentNumber': '9310', 'obligationNumber': '204', 'obligorNumber': '9310', 'sequenceNumber': '1'}],
    "TOPIC_account_loanslinesleases_billingschedules": [{'topic_name': 'account-loanslinesleases-billingschedules', 'accountLoanslinesleasesBillingscheduleId': 'T11-0001', 'accountLoanslinesleaseId': 'ACC-0001', 'productRateId': 'T33-0001', 'applicationNumber': 'APP01', 'applicationSystem': 'AFSVISION', 'bankNumber': '001', 'chargeCode': '10', 'effectiveStartDate': '2026-09-01', 'financialInstrumentNumber': '4521', 'obligationNumber': '88012', 'obligorNumber': '4521'}, {'topic_name': 'account-loanslinesleases-billingschedules', 'accountLoanslinesleasesBillingscheduleId': 'T11-0002', 'accountLoanslinesleaseId': 'ACC-0002', 'productRateId': 'T33-0002', 'applicationNumber': 'APP01', 'applicationSystem': 'AFSVISION', 'bankNumber': '001', 'chargeCode': '22', 'effectiveStartDate': '2026-09-01', 'financialInstrumentNumber': '9310', 'obligationNumber': '204', 'obligorNumber': '9310'}],
    "account_loanslinesleases_chargeheaders_amounts": [{'topic_name': 'account-loanslinesleases-chargeheaders-amounts', 'accountLoanslinesleasesChargeheadersAmountId': 'T12-0001', 'accountLoanslinesleasesChargeheaderId': 'T8-0001', 'amountFieldName': 'PRINCIPAL', 'applicationNumber': 'APP01', 'applicationSystem': 'AFSVISION', 'bankNumber': '001', 'chargeCode': '10', 'financialInstrumentNumber': '4521', 'obligationNumber': '88012', 'obligorNumber': '4521'}, {'topic_name': 'account-loanslinesleases-chargeheaders-amounts', 'accountLoanslinesleasesChargeheadersAmountId': 'T12-0002', 'accountLoanslinesleasesChargeheaderId': 'T8-0002', 'amountFieldName': 'INTEREST', 'applicationNumber': 'APP01', 'applicationSystem': 'AFSVISION', 'bankNumber': '001', 'chargeCode': '22', 'financialInstrumentNumber': '9310', 'obligationNumber': '204', 'obligorNumber': '9310'}],
    "account_loanslinesleases_balanceheaders_amounts": [{'topic_name': 'account-loanslinesleases-balanceheaders-amounts', 'accountLoanslinesleasesBalanceheadersAmountId': 'T15-0001', 'accountLoanslinesleasesBalanceheaderId': 'T7-0001', 'amountFieldName': 'PRINCIPAL', 'applicationNumber': 'APP01', 'applicationSystem': 'AFSVISION', 'associatedPrincipalBalanceCode': 'P', 'balanceCode': 'CUR', 'bankNumber': '001', 'financialInstrumentNumber': '4521', 'obligationNumber': '88012', 'obligorNumber': '4521', 'sequenceNumber': '1'}, {'topic_name': 'account-loanslinesleases-balanceheaders-amounts', 'accountLoanslinesleasesBalanceheadersAmountId': 'T15-0002', 'accountLoanslinesleasesBalanceheaderId': 'T7-0002', 'amountFieldName': 'INTEREST', 'applicationNumber': 'APP01', 'applicationSystem': 'AFSVISION', 'associatedPrincipalBalanceCode': 'P', 'balanceCode': 'CUR', 'bankNumber': '001', 'financialInstrumentNumber': '9310', 'obligationNumber': '204', 'obligorNumber': '9310', 'sequenceNumber': '1'}],
}

def run():
    parser = argparse.ArgumentParser()
    parser.add_argument("--out_dir", default="dummy_data_all11")
    parser.add_argument("--gcs_bucket", default=None)
    args = parser.parse_args()

    if args.gcs_bucket:
        from google.cloud import storage
        client = storage.Client()
        bucket = client.bucket(args.gcs_bucket)
        for name, records in TOPIC_FILES.items():
            blob = bucket.blob(f"dummy/{name}.jsonl")
            body = "\n".join(json.dumps(r) for r in records)
            blob.upload_from_string(body)
            print(f"Uploaded gs://{args.gcs_bucket}/dummy/{name}.jsonl ({len(records)} records)")
        return

    os.makedirs(args.out_dir, exist_ok=True)
    for name, records in TOPIC_FILES.items():
        path = os.path.join(args.out_dir, f"{name}.jsonl")
        with open(path, "w") as f:
            for r in records:
                f.write(json.dumps(r) + "\n")
        print(f"Wrote {path} ({len(records)} records)")

if __name__ == "__main__":
    run()
